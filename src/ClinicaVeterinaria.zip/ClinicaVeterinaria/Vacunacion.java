/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AnimalLife;

import java.time.LocalDate;

/**
 *
 * @author USUARIO
 */
public class Vacunacion extends ServicioVeterianio{
    private String tipoVacunacion;
    
    private double valorVacuna;
    
    private double Costo = valorVacuna + 15000;

    public Vacunacion(String tipoVacunacion, Mascota mascota, PersonalVeterinario veterinario, LocalDate fehca) {
        super(mascota, veterinario, fehca);
        this.tipoVacunacion = tipoVacunacion;
    }

    public String getTipoVacunacion() {
        return tipoVacunacion;
    }

    public void setTipoVacunacion(String tipoVacunacion) {
        this.tipoVacunacion = tipoVacunacion;
    }

    public double getValorVacuna() {
        return valorVacuna;
    }

    public void setValorVacuna(double valorVacuna) {
        this.valorVacuna = valorVacuna;
    }

    public double getCosto() {
        return Costo;
    }

    public void setCosto(double Costo) {
        this.Costo = Costo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
    
    
}
