/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AnimalLife;

import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class VeterinarioEspecializado extends PersonalVeterinario {

    public VeterinarioEspecializado(String Nombre, String id, String Especialidad) {
        super(Nombre, id, Especialidad);
        this.Nombre = Nombre;
        this.id = id;
        this.Especialidad = Especialidad;
    }

    @Override
    public String getNombre() {
        return Nombre;
    }

    @Override
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getEspecialidad() {
        return Especialidad;
    }

    @Override
    public void setEspecialidad(String Especialidad) {
        this.Especialidad = Especialidad;
    }

    public String Especialidades() {
        System.out.println("Dermatologo");
        System.out.println("Mas");
        return Especialidades();

    }

    public ArrayList<String> atenderMascotas() {
        return atenderMascotas();
    }

    public ArrayList<String> VerHistorialMascotas() {
        return VerHistorialMascotas();

    }

    @Override
    public String toString() {
        return "VeterinarioEspecializado{" + "nombre: " + Nombre + "identificación: " + id + " Especialidad: " + Especialidad + '}';
    }

    void add() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void add(VeterinarioEspecializado VE) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
