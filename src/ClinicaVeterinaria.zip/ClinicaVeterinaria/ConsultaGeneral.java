/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AnimalLife;

import java.time.LocalDate;

/**
 *
 * @author USUARIO
 */
public class ConsultaGeneral extends ServicioVeterianio{
    
    private double CostoF = 50000;
    
    public ConsultaGeneral(Mascota mascota, PersonalVeterinario veterinario, LocalDate fehca) {
        super(mascota, veterinario, fehca);
    }

    public double getCostoF() {
        return CostoF;
    }

    public void setCostoF(double CostoF) {
        this.CostoF = CostoF;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    @Override
    public double calcularCosto() {
       
        return CostoF;
    }

    
    
 
}
