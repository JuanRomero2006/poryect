/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AnimalLife;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class ClinicaVeterinaria {
    
    private List<Mascota> listarestaurante;
    
    private List<PersonalVeterinario> listaPersonalVeterinarios;
    
    private List<ServicioVeterianio> listaServicioVeterianios;
    
    private HashMap<Mascota, List<ServicioVeterianio>> HistorialDeServicio;

    public ClinicaVeterinaria(List<Mascota> listarestaurante, List<PersonalVeterinario> listaPersonalVeterinarios, List<ServicioVeterianio> listaServicioVeterianios, HashMap<Mascota, List<ServicioVeterianio>> HistorialDeServicio) {
        this.listarestaurante = listarestaurante;
        this.listaPersonalVeterinarios = listaPersonalVeterinarios;
        this.listaServicioVeterianios = listaServicioVeterianios;
        this.HistorialDeServicio = HistorialDeServicio;
    }

    public List<Mascota> getListarestaurante() {
        return listarestaurante;
    }

    public void setListarestaurante(List<Mascota> listarestaurante) {
        this.listarestaurante = listarestaurante;
    }

    public List<PersonalVeterinario> getListaPersonalVeterinarios() {
        return listaPersonalVeterinarios;
    }

    public void setListaPersonalVeterinarios(List<PersonalVeterinario> listaPersonalVeterinarios) {
        this.listaPersonalVeterinarios = listaPersonalVeterinarios;
    }

    public List<ServicioVeterianio> getListaServicioVeterianios() {
        return listaServicioVeterianios;
    }

    public void setListaServicioVeterianios(List<ServicioVeterianio> listaServicioVeterianios) {
        this.listaServicioVeterianios = listaServicioVeterianios;
    }

    public HashMap<Mascota, List<ServicioVeterianio>> getHistorialDeServicio() {
        return HistorialDeServicio;
    }

    public void setHistorialDeServicio(HashMap<Mascota, List<ServicioVeterianio>> HistorialDeServicio) {
        this.HistorialDeServicio = HistorialDeServicio;
    }

    @Override
    public String toString() {
        return "ClinicaVeterinaria{" + "listarestaurante=" + listarestaurante + ", listaPersonalVeterinarios=" + listaPersonalVeterinarios + ", listaServicioVeterianios=" + listaServicioVeterianios + ", HistorialDeServicio=" + HistorialDeServicio + '}';
    }
    
    
    
    
}
