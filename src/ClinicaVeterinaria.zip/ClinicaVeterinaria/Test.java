/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AnimalLife;

import java.time.LocalDate;

/**
 *
 * @author USUARIO
 */
public class Test {
    public static void main(String[] args) {
        
        //Veterinario Es
        VeterinarioEspecializado VE = new VeterinarioEspecializado("juan" , "123", "cardiolgo");
        System.out.println(VE);
        
        //veterinario Ge
        VeterianroGeneral VG = new VeterianroGeneral("juan", "123");
        System.out.println(VG);
        
        //Servicios
       
        Mascota M = new Mascota("juanito", "perro", 2, "daniel");
        System.out.println(M);
        
        VE.add("juan");
        
        
}
}
