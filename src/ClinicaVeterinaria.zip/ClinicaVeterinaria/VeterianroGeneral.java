/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AnimalLife;

import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class VeterianroGeneral extends PersonalVeterinario {

    public VeterianroGeneral(String Nombre, String id) {
        super(Nombre, id);

    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEspecialidad() {
        return Especialidad;
    }

    public void setEspecialidad(String Especialidad) {
        this.Especialidad = Especialidad;
    }
    
    
    @Override
    public String toString() {
        return "VeterinarioEspecializado{" + "nombre: " + Nombre +  "identificación: " + id + " Especialidad: General }";
        
    }
    

    
}
