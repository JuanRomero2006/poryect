/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AnimalLife;

import java.time.LocalDate;

/**
 *
 * @author USUARIO
 */
public class Cirugia extends ServicioVeterianio{
    
    private int timpoCirugia;
    private double CostoCirugia = 75000;
    private int NivelComplejidad;
    private double Costo;
    
    public Cirugia(Mascota mascota, PersonalVeterinario veterinario, LocalDate fehca) {
        super(mascota, veterinario, fehca);
    }

    @Override
    public double calcularCosto() {
        Costo = timpoCirugia * CostoCirugia;
        if (NivelComplejidad > 10 || NivelComplejidad < 50) {
            CostoCirugia = CostoCirugia * 0.25;
            
        }else if (NivelComplejidad >50 ) {
            CostoCirugia = CostoCirugia * 0.40;
        }
        
        return super.calcularCosto();
    }
    
    
    
}
