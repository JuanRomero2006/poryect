/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AnimalLife;

import java.time.*;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author USUARIO
 */
public abstract class ServicioVeterianio {

    LocalDate fecha = LocalDate.now(); // Fecha actual 
    
    private Mascota mascota;
    private PersonalVeterinario veterinario;
    private LocalDate fehca;

    public ServicioVeterianio(Mascota mascota, PersonalVeterinario veterinario, LocalDate fehca) {
        this.mascota = mascota;
        this.veterinario = veterinario;
        this.fehca = fehca;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public void setMascota(Mascota mascota) {
        this.mascota = mascota;
    }

    public PersonalVeterinario getVeterinario() {
        return veterinario;
    }

    public void setVeterinario(PersonalVeterinario veterinario) {
        this.veterinario = veterinario;
    }

    public LocalDate getFehca() {
        return fehca;
    }

    public void setFehca(LocalDate fehca) {
        this.fehca = fehca;
    }
    
    //Metodo de calcualr costo
    public double calcularCosto(){
        
        return calcularCosto();
        
    }    
    
    public String generarInforme(){
        
        return generarInforme();
    }
    
    
    
}
