/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author USUARIO
 */
public class Asignacion extends Vehiculos{
    private Vehiculos vehiculosAsignado;
    private Ruta ruta;
    private LocalDate fechaInicial;

    public Asignacion(Vehiculos vehiculosAsignado, Ruta ruta, LocalDate fechaInicial, String ID, String Moldelo, int CantidadPasajeros, double VelocidadActual) {
        super(ID, Moldelo, CantidadPasajeros, VelocidadActual);
        this.vehiculosAsignado = vehiculosAsignado;
        this.ruta = ruta;
        this.fechaInicial = fechaInicial;
    }
    
    public Asignacion(Vehiculos vehiculosAsignado, Ruta ruta, LocalDate fechaInicial){
        super("", "", 0, 0);
        this.vehiculosAsignado = vehiculosAsignado;
        this.ruta = ruta;
        this.fechaInicial = fechaInicial;
    }

    public Vehiculos getVehiculosAsignado() {
        return vehiculosAsignado;
    }

    public void setVehiculosAsignado(Vehiculos vehiculosAsignado) {
        this.vehiculosAsignado = vehiculosAsignado;
    }

    public Ruta getRuta() {
        return ruta;
    }

    public void setRuta(Ruta ruta) {
        this.ruta = ruta;
    }

    public LocalDate getFechaInicial() {
        return fechaInicial;
    }

    public void setFechaInicial(LocalDate fechaInicial) {
        this.fechaInicial = fechaInicial;
    }

    @Override
    public String toString() {
        return "Asignacion{" + "vehiculosAsignado=" + vehiculosAsignado + ", ruta=" + ruta + ", fechaInicial=" + fechaInicial + '}';
    }
    
    public void mostrarDetallesAsignacion() {
        System.out.println("=== Detalles de la Asignación ===");
        System.out.println("Vehículo asignado ID: " + vehiculosAsignado.getID());
        System.out.println("Ruta: " + ruta.getNombreRuta());
        System.out.println("Puntos de interés:");

        for (String punto : ruta.getPuntoInteres()) {
            System.out.println(" - " + punto);
        }
    }
    
    public int calculaDiasAsignado(){
        return (int) ChronoUnit.DAYS.between(fechaInicial, LocalDate.now());
    }

    @Override
    public boolean realizarInspeccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double ejecutaMantenimiento() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
