/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

/**
 *
 * @author USUARIO
 */
public abstract class Vehiculos implements IServicioMantenimiento{
    String ID;
    private String Modelo;
    private int CantidadPasajeros;
    double VelocidadActual;

    public Vehiculos(String ID, String Moldelo, int CantidadPasajeros, double VelocidadActual) {
        this.ID = ID;
        this.Modelo = Moldelo;
        this.CantidadPasajeros = CantidadPasajeros;
        this.VelocidadActual = VelocidadActual;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getMoldelo() {
        return Modelo;
    }

    public void setMoldelo(String Moldelo) {
        this.Modelo = Moldelo;
    }

    public int getCantidadPasajeros() {
        return CantidadPasajeros;
    }

    public void setCantidadPasajeros(int CantidadPasajeros) {
        this.CantidadPasajeros = CantidadPasajeros;
    }

    public double getVelocidadActual() {
        return VelocidadActual;
    }

    public void setVelocidadActual(double VelocidadActual) {
        this.VelocidadActual = VelocidadActual;
    }
    
    public double CalcularAutonomia(){
        
        return 0;
        
    } 
    
    public String MostrarInfo(){
 
        return "Información del vehiculo: " + " ID= " + ID + ", Moldelo= " + Modelo + ", CantidadPasajeros= " + CantidadPasajeros + ", VelocidadActual= " + VelocidadActual ;
    }

    @Override
    public String toString() {
        return "Vehiculos{" + "ID=" + ID + ", Moldelo=" + Modelo + ", CantidadPasajeros=" + CantidadPasajeros + ", VelocidadActual=" + VelocidadActual + '}';
    }
     
}
