/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Flota_de_vehiculos;

/**
 *
 * @author USUARIO
 */
public interface IServicioMantenimiento {

    boolean realizarInspeccion();
    
    double ejecutaMantenimiento();

}
