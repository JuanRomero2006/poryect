/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

/**
 *
 * @author USUARIO
 */
public abstract class VehiculoElectrico extends Vehiculos{
    
    int NivelBateria;

    public VehiculoElectrico(int NivelBateria, String ID, String Moldelo, int CantidadPasajeros, double VelocidadActual) {
        super(ID, Moldelo, CantidadPasajeros, VelocidadActual);
        this.NivelBateria = NivelBateria;
    }

    public int getNivelBateria() {
        return NivelBateria;
    }

    public void setNivelBateria(int NivelBateria) {
        this.NivelBateria = NivelBateria;
    }

    @Override
    public String toString() {
        return "VehiculoElectrico{" + "NivelBateria=" + NivelBateria + '}';
    }
    
}
