/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

/**
 *
 * @author USUARIO
 */
public abstract class VehiculoTerreste extends Vehiculos{
    
    private String TipoNeumatico ;

    public VehiculoTerreste(String TipoNeumatico, String ID, String Moldelo, int CantidadPasajeros, double VelocidadActual) {
        super(ID, Moldelo, CantidadPasajeros, VelocidadActual);
        this.TipoNeumatico = TipoNeumatico;
    }

    public String getTipoNeumatico() {
        return TipoNeumatico;
    }

    public void setTipoNeumatico(String TipoNeumatico) {
        this.TipoNeumatico = TipoNeumatico;
    }

    @Override
    public String toString() {
        return "VehiculoTerreste{" + "TipoNeumatico=" + TipoNeumatico + '}';
    }
    
}
