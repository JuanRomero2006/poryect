/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

/**
 *
 * @author USUARIO
 */
public class Camioneta extends VehiculoTerreste implements IServicioMantenimiento {

    private double CapacidadCargaKg;

    public Camioneta(double CapacidadCargaKg, String TipoNeumatico, String ID, String Moldelo, int CantidadPasajeros, double VelocidadActual) {
        super(TipoNeumatico, ID, Moldelo, CantidadPasajeros, VelocidadActual);
        this.CapacidadCargaKg = CapacidadCargaKg;
    }

    public double getCapacidadCargaKg() {
        return CapacidadCargaKg;
    }

    public void setCapacidadCargaKg(double CapacidadCargaKg) {
        this.CapacidadCargaKg = CapacidadCargaKg;
    }

    @Override
    public String toString() {
        return "Camioneta{" + "CapacidadCargaKg=" + CapacidadCargaKg + '}';
    }

    //Metodos Vehiculo
    @Override
    public String MostrarInfo() {
        return super.MostrarInfo() + ", Capacoidad de carga= " + CapacidadCargaKg + " Kg";

    }

    @Override
    public double CalcularAutonomia() {
        return super.CalcularAutonomia(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    //IServicioMantenimiento
    @Override
    public boolean realizarInspeccion() {

        if (CapacidadCargaKg > 1000.0) {
            System.out.println("El vehículo requiere mantenimiento.");
            return true; 
        } else {
            System.out.println("OK. El vehículo está en buenas condiciones.");
            return false; 
        }

    }

    @Override
    public double ejecutaMantenimiento() {
        if (realizarInspeccion() == true) {
            System.out.println("Realizando mantenimiento del automóvil");
            CapacidadCargaKg = 500;
        }
        return CapacidadCargaKg;
    }
}
