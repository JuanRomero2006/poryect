/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

/**
 *
 * @author USUARIO
 */
public class Automovil extends VehiculoTerreste implements IServicioMantenimiento {

    private double TamañoMaletero;

    public Automovil(double TamañoMaletero, String TipoNeumatico, String ID, String Moldelo, int CantidadPasajeros, double VelocidadActual) {
        super(TipoNeumatico, ID, Moldelo, CantidadPasajeros, VelocidadActual);
        this.TamañoMaletero = TamañoMaletero;
    }

    public double getTamañoMaletero() {
        return TamañoMaletero;
    }

    public void setTamañoMaletero(double TamañoMaletero) {
        this.TamañoMaletero = TamañoMaletero;
    }

    @Override
    public String toString() {
        return "Automovil{" + "Tama\u00f1oMaletero=" + TamañoMaletero + '}';
    }

    //Metodos Vehiculo
    @Override
    public String MostrarInfo() {
        return super.MostrarInfo() + ", Tamaño del maletero= " + TamañoMaletero;
    }

    @Override
    public double CalcularAutonomia() {

        return super.CalcularAutonomia();
    }

    //IServicioMantenimiento
    @Override
    public boolean realizarInspeccion() {

        if (TamañoMaletero < 0.5) {
            System.out.println("El vehículo requiere mantenimiento.");
            return true; 
        } else {
            System.out.println("OK, El vehículo está en buenas condiciones.");
            return false; 
        }
    }

    @Override
    public double ejecutaMantenimiento() {
        if (realizarInspeccion() == true) {
            System.out.println("Realizando mantenimiento del automóvil");
            TamañoMaletero = 1.0;
        }
        return TamañoMaletero;
    }   
}