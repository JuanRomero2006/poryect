/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

import Flota_de_vehiculos.Exeptiones.AsignacionInvalidaException;
import Flota_de_vehiculos.Exeptiones.AsignacionNoEncontradaException;
import Flota_de_vehiculos.Exeptiones.VehiculoNoEncontradoException;
import Flota_de_vehiculos.Exeptiones.RutaNoEncontradaException;
import Flota_de_vehiculos.Exeptiones.IDDuplicadoException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author USUARIO
 */
public class FlotaManager {

    public static void main(String[] args) {

        try {
            FlotaManager manager = new FlotaManager();

            // === Vahiculos ===
            //V1
            Vehiculos V1 = new Automovil(-1, "CIDUDAD", "ABC123", "2025", 5, 20);
            manager.agregarVehiculo(V1);
            //Metodos V1
            manager.ejecutarMantenimientoCritico();
            System.out.println(V1.MostrarInfo());
            
            // Se agraga

            //V2
            Vehiculos V2 = new Camioneta(1000, "TRD", "ABC124", "2024", 5, 20);
            manager.agregarVehiculo(V2);
            manager.ejecutarMantenimientoCritico();
            System.out.println(V2.MostrarInfo());
            // Metodos V2

            System.out.println(manager.obtenerVehiculo("ABC124"));

            // ====== Ruta ======
            Ruta ruta = new Ruta("RB1", "Bogota", 20);
            manager.crearRuta(ruta);
            System.out.println(manager.obtenerRuta("RB2"));

            // ====== Asignacion de vehiculos ======
            manager.asignarVehiculoARuta("ABC123", "RB1", "01/01/2000");

            // === Exeptiones ===
        } catch (IDDuplicadoException e) {
            System.out.println("Error de duplicado: " + e.getMessage());

        } catch (VehiculoNoEncontradoException e) {
            System.out.println("Vehículo no encontrado: " + e.getMessage());

        } catch (NumberFormatException e) {
            System.out.println("Formato numérico incorrecto detectado: " + e.getMessage());

        } catch (RutaNoEncontradaException e) {
            System.out.println("Error de ruta no encontrada: " + e.getMessage());

        } catch (AsignacionNoEncontradaException e) {
            System.out.println("Error de asigancion de rutas: " + e.getMessage());

        } catch (Exception e) {
            // Captura cualquier otro error inesperado
            System.out.println("Error desconocido: " + e.getMessage());

        } finally {
            System.out.println("Bloque finally ejecutado: el programa cerró correctamente.");
        }

    }

    //=========== Estracturas que alamcenan ===========
    // Colección central 1
    private HashMap<String, Vehiculos> flota = new HashMap<>();

    // Colección central 2
    private HashMap<String, Ruta> rutasDisponibles = new HashMap<>();

    // Colección central 3
    private ArrayList<Asignacion> asignacionesActivas = new ArrayList<>();

    // ===== Gestion de vehiculos =====
    //Se agregan los vehiculos
    public void agregarVehiculo(Vehiculos V) throws IDDuplicadoException {
        if (flota.containsKey(V.getID())) {
            throw new IDDuplicadoException("El vehículo con ID '" + V.getID() + "' ya existe.");
        }
        flota.put(V.getID(), V);
    }

    // Obtener vehiculo
    public Vehiculos obtenerVehiculo(String ID) throws VehiculoNoEncontradoException {
        if (!flota.containsKey(ID)) {
            throw new VehiculoNoEncontradoException("No existe vehículo con ID '" + ID + "'");
        }
        return flota.get(ID);
    }

    // Se ejecuta el mantenimiento
    public void ejecutarMantenimientoCritico() {
        for (Vehiculos v : flota.values()) {

            if (v.realizarInspeccion()) {
                System.out.println("Vehículo ID " + v.getID() + " requiere mantenimiento — reparando…");
                v.ejecutaMantenimiento();
            } else {
                System.out.println("Vehículo ID " + v.getID() + " está en buen estado — sin acciones.");
            }
        }
    }

    // ===== Gestión de Rutas =====
    //Agregar ruta
    public void crearRuta(Ruta ruta) throws IDDuplicadoException {
        if (rutasDisponibles.containsKey(ruta.getIdRuta())) {
            throw new IDDuplicadoException("La ruta con ID '" + ruta.getIdRuta() + "' ya existe.");
        }
        rutasDisponibles.put(ruta.getIdRuta(), ruta);
    }

    //Obtener ruta
    public Ruta obtenerRuta(String idRuta) throws RutaNoEncontradaException {
        if (!rutasDisponibles.containsKey(idRuta)) {
            throw new RutaNoEncontradaException("No existe la ruta con ID '" + idRuta + "'");
        }
        return rutasDisponibles.get(idRuta);
    }

    // ===== Gestión de Asignaciones =====
    //Agregar asignacion
    public void agregarAsignacion(Asignacion asignacion) {
        asignacionesActivas.add(asignacion);
    }

    //Obtener asignacion
    public ArrayList<Asignacion> obtenerAsignacionesActivas() {
        return asignacionesActivas;
    }

    // ===== Gestión de Asignacion de vehiculos =====
    // Asignar vehoculos a al ruta
    public void asignarVehiculoARuta(String idVehiculo, String idRuta, String fecha)
            throws VehiculoNoEncontradoException, RutaNoEncontradaException, AsignacionInvalidaException {

        // Verificar vehículo
        Vehiculos vehiculo = flota.get(idVehiculo);
        if (vehiculo == null) {
            throw new VehiculoNoEncontradoException("No existe vehículo con ID '" + idVehiculo + "'");
        }

        // Verificar ruta
        Ruta ruta = rutasDisponibles.get(idRuta);
        if (ruta == null) {
            throw new RutaNoEncontradaException("No existe la ruta con ID '" + idRuta + "'");
        }

        // Lógica de negocio
        if (vehiculo instanceof Camioneta && ruta.getDistanciaKM() <= 100) {
            throw new AsignacionInvalidaException(
                    "Las camionetas solo pueden asignarse a rutas mayores a 100 km. Distancia actual: "
                    + ruta.getDistanciaKM() + " km."
            );
        }

        // Al pasar todo, se crea al asignacion
        Asignacion nuevaAsignacion = new Asignacion(vehiculo, ruta, LocalDate.MIN);
        asignacionesActivas.add(nuevaAsignacion);

        System.out.println("Asignación realizada correctamente.");
    }
}
