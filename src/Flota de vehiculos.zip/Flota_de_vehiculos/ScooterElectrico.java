/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

/**
 *
 * @author USUARIO
 */
public class ScooterElectrico extends VehiculoElectrico implements IServicioMantenimiento{
    
    private boolean esPlegable;

    public ScooterElectrico(boolean Desplegable, int NivelBateria, String ID, String Moldelo, int CantidadPasajeros, double VelocidadActual) {
        super(NivelBateria, ID, Moldelo, CantidadPasajeros, VelocidadActual);
        this.esPlegable = Desplegable;
    }

    public boolean isesPlegable() {
        return esPlegable;
    }

    public void setesPlegable(boolean Desplegable) {
        this.esPlegable = Desplegable;
    }

    @Override
    public String toString() {
        return "ScooterElectrico{" + "Desplegable=" + esPlegable + '}';
    }
    
    //Metodos Vehiculo

    @Override
    public String MostrarInfo() {
        return super.MostrarInfo() + ", Es desplegable= " + esPlegable + ", Nivel de Bateria= " + NivelBateria + " %";
    }

    @Override
    public double CalcularAutonomia() {
        return super.CalcularAutonomia(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
    
    //IServicioMantenimiento

    @Override
    public boolean realizarInspeccion() {
        if (getNivelBateria() < 20) {
            System.out.println("El vehículo requiere mantenimiento.");
            return true; 
        } else {
            System.out.println("OK. El vehículo está en buenas condiciones.");
            return false; 
        }
    }

    @Override
    public double ejecutaMantenimiento() {
        if (realizarInspeccion() == true) {
            System.out.println("Realizando mantenimiento del automóvil");
            NivelBateria = 100;
        }
        return NivelBateria;
    }
}
    
