/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos;

import java.util.ArrayList;

/**
 *
 * @author USUARIO
 */
public class Ruta {
    private String idRuta;
    private String nombreRuta;
    private double distanciaKM;
    private  ArrayList<String> puntoInteres;
    
    public Ruta(String idRuta, String nombreRuta, double distanciaKM) {
        this.idRuta = idRuta;
        this.nombreRuta = nombreRuta;
        this.distanciaKM = distanciaKM;
    }

    public String getIdRuta() {
        return idRuta;
    }

    public void setIdRuta(String idRuta) {
        this.idRuta = idRuta;
    }

    public String getNombreRuta() {
        return nombreRuta;
    }

    public void setNombreRuta(String nombreRuta) {
        this.nombreRuta = nombreRuta;
    }

    public double getDistanciaKM() {
        return distanciaKM;
    }

    public void setDistanciaKM(double distanciaKM) {
        this.distanciaKM = distanciaKM;
    }

    public ArrayList<String> getPuntoInteres() {
        return puntoInteres;
    }

    public void setPuntoInteres(ArrayList<String> puntoInteres) {
        this.puntoInteres = puntoInteres;
    }

    @Override
    public String toString() {
        return "Ruta{" + "idRuta=" + idRuta + ", nombreRuta=" + nombreRuta + ", distanciaKM=" + distanciaKM + ", puntoInteres=" + puntoInteres + '}';
    }
    
    public ArrayList<String> agregarPunto(String Punto){
        
        puntoInteres.add(Punto);
        
        return puntoInteres;
        
    }
    
    
    
}
