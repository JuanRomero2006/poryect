/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flota_de_vehiculos.Exeptiones;

/**
 *
 * @author USUARIO
 */
public class RutaNoEncontradaException extends RuntimeException{
    
    public RutaNoEncontradaException (String mensaje){
        super(mensaje);
    }
}
